File 0-print_name.c is a function that prints a name.

File 1-array_iterator.c is a function that executes a function given as a parameter on each element of an array.

File 2-int_index.c is a function that searches for an integer.

Files 3-main.c, 3-op_functions.c, 3-get_op_func.c, 3-calc.h are part of a program that performs simple operations.

File function_pointers.h is the header file that contains all these functions' prototypes.
