#ifndef FILE_MAIN
#define FILE_MAIN

int _putchar(char c);
int _atoi(char *s);

#endif
